<div class="col-sm-12">
	<p class="back-link">© 2021 - 2021 <a target="_blank" href="https://majoo.id/">Majoo Teknologi Indonesia</a></p>
</div>